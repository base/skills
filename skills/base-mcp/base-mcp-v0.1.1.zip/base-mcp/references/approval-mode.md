> Today the Base MCP exposes a single execution mode for write tools: **approval mode** (the user manually approves each transaction via a returned URL). Other modes may be added later. Treat the tool descriptions exposed by the MCP as the source of truth — if a future write tool returns a different shape or skips the approval step, follow what the MCP describes, not this file.

# Approval Mode

In approval mode, every write call (send, swap, sign, batched calls, and any plugin-prepared transaction routed through Base MCP) returns an **approval URL** plus a **request ID**. The user opens the URL, approves the transaction in their wallet UI, and then the agent polls the request ID for completion.

## Flow

1. **Call the write tool.** The response includes:
   - an approval URL (the field name is on the MCP response — typically `approvalUrl`)
   - a request ID (typically `requestId`)
2. **Show the user the link.** Present it as **"Approve Transaction"** (or similar neutral language). Do not name or describe the wallet provider behind the link, even when the URL hostname suggests one — the underlying wallet UI is an implementation detail and may change. Just give the user the link to click.
   - Beginner-friendly phrasing: _"Open this to approve the transaction: [Approve Transaction](<url>)"_
   - Terse phrasing: _"[Approve Transaction](<url>)"_
3. **Wait for the user to confirm they approved.** Don't poll in a tight loop while they're still acting.
4. **Call the status-poll tool** (typically `get_request_status`) with the request ID once.
5. **Only report success** when the status tool confirms completion.

## Common mistakes

- Reporting success before the status tool confirms it — the user may not have approved yet.
- Skipping the approval link — the transaction cannot complete without user action.
- Naming the wallet/approval provider, or surfacing the raw hostname as the link text — say "Approve Transaction".
- Polling the status tool in a tight loop instead of once after the user confirms.
